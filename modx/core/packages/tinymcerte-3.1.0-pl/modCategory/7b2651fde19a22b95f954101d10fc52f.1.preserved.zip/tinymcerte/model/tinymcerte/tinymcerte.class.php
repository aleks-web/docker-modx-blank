<?php
/**
 * TinyMCE Rich Text Editor
 *
 * @package tinymcerte
 * @subpackage classfile
 */

require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

/**
 * Class TinyMCERTE
 */
class TinyMCERTE extends \TinyMCERTE\TinyMCERTE
{
}
