<?php
/**
 * TinyMCE Rich Text Editor
 *
 * @package tinymcerte
 * @subpackage classfile
 */

require_once dirname(dirname(__DIR__)) . '/vendor/autoload.php';

/**
 * Class TinyMCERTE
 */
class TinyMCERTE extends \TinyMCERTE\TinyMCERTE
{
}
